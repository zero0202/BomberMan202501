// Copyright Epic Games, Inc. All Rights Reserved.

#include "BomberMan202501.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, BomberMan202501, "BomberMan202501" );
 